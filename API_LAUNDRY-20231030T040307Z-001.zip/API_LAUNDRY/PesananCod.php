<?php
include 'conn.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_pesanan = $_POST['id_pesanan'];
    $waktu = $_POST['waktu_penjemputan'];

    if ($waktu == "Antar Sendiri") {
        //Bayar ditoko
        $queryUpdate = "UPDATE pesanan SET status_pesanan = 'Menunggu diantar' WHERE id_pesanan = '$id_pesanan'";
        $result = mysqli_query($konek, $queryUpdate);
    } else {
        //Masih Bingung
        $queryUpdate = "UPDATE pesanan SET status_pesanan = 'Sedang dijemput' WHERE id_pesanan = '$id_pesanan'";
        $result = mysqli_query($konek, $queryUpdate);
    }


    // $queryUpdate = "UPDATE pesanan SET status_pesanan = 'Menunggu diproses' WHERE id_pesanan = '$id_pesanan'";
    // $result = mysqli_query($konek, $queryUpdate);

    $check = mysqli_affected_rows($konek);
    if ($check > 0) {
        $response['kode'] = 1;
        $response['message'] = "Data COD sedang Menunggu diproses";
    } else {
        $response['kode'] = 0;
    }
    echo json_encode($response);
    mysqli_close($konek);
}