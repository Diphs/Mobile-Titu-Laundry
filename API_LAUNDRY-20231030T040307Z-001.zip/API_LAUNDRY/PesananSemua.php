<?php
require('conn.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $id_user = $_POST['id_user'];

    $query = "SELECT jasa.jenis_jasa,pesanan.total_berat,pesanan.status_pesanan, 
    TIME(pesanan.waktu_antar) AS waktu_mengantar,TIME(pesanan.waktu_penjemputan) AS waktu_penjemputan , pesanan.total_harga ,jasa.image
    FROM pesanan JOIN jasa ON pesanan.id_jasa = jasa.id_jasa WHERE id_user = '$id_user' ORDER BY pesanan.id_pesanan DESC;";
    $result = mysqli_query($konek, $query);
    $row = mysqli_affected_rows($konek);

    if ($row > 0) {
        $respone['kode'] = 1;
        $respone['message'] = "Pesanan User Tersedia";
        $respone['data'] = array();

        while ($getData = mysqli_fetch_object($result)) {
            $F['jenis_jasa'] = $getData->jenis_jasa;
            $F['total_berat'] = $getData->total_berat;
            $F['status_pesanan'] = $getData->status_pesanan;
            $F['waktu_antar'] = $getData->waktu_mengantar;
            $F['waktu_penjemputan'] = $getData->waktu_penjemputan;
            $F['total_harga'] = $getData->total_harga;
            $F['image'] = $getData->image;

            array_push($respone['data'], $F);
        }
    } else {
        $respone['kode'] = 0;
        $respone['message'] = "Pesanan User Tersedia";
    }
    echo json_encode($respone);
    mysqli_close($konek);
}