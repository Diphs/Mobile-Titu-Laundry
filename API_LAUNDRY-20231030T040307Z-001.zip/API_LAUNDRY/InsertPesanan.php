<?php
require('conn.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $total_berat = $_POST['total_berat'];
    $total_harga = $_POST['total_harga'];
    $harga_diskon = $_POST['harga_diskon'];
    $waktu_penjemputan = $_POST['waktu_penjemputan'];
    $waktu_antar = $_POST['waktu_antar'];
    $id_voucher = $_POST['id_voucher'];
    $id_user = $_POST['id_user'];
    $id_jasa = $_POST['id_jasa'];
    $alamat_jemput = $_POST['alamat_penjemputan'];
    $alamat_kirim = $_POST['alamat_pengiriman'];

    date_default_timezone_set('Asia/Kolkata');
    $date = date('Y-m-d');


    if ($waktu_penjemputan == "Antar Sendiri" || $waktu_antar == "Antar Sendiri") {
        $queryPesanan = "INSERT INTO pesanan(tanggal,total_berat,total_harga,harga_diskon,alamat_penjemputan , waktu_penjemputan,alamat_pengiriman,waktu_antar,status_pesanan,id_voucher,id_user,id_jasa)
        VALUES ('$date','$total_berat','$total_harga','$harga_diskon','','0000-00-00 00:00:00','','0000-00-00 00:00:00','Menunggu pembayaran','$id_voucher','$id_user','$id_jasa');";
    } else {
        $queryPesanan = "INSERT INTO pesanan(tanggal,total_berat,total_harga,harga_diskon,alamat_penjemputan , waktu_penjemputan,alamat_pengiriman,waktu_antar,status_pesanan,id_voucher,id_user,id_jasa)
        VALUES ('$date','$total_berat','$total_harga','$harga_diskon','$alamat_jemput','$waktu_penjemputan','$alamat_kirim','$waktu_antar','Menunggu pembayaran','$id_voucher','$id_user','$id_jasa');";
    }
    $result = mysqli_query($konek, $queryPesanan);
    $check = mysqli_affected_rows($konek);

    $id_pesanan = $konek->insert_id;

    if ($check > 0) {
        $response['kode'] = 1;
        $response['message'] = "Data Masuk";
        $response['data'] = [
            'id_pesanan' => $id_pesanan
        ];
    } else {
        $response['kode'] = 0;
        $response['message'] = "Data Gagal Masuk";
    }
    echo json_encode($response);
    mysqli_close($konek);
}