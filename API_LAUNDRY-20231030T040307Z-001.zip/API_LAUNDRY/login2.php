<?php

include 'conn.php';

if ($_POST) {

    //Data
    $email = $_POST['email'];
    $pass = $_POST['password'];

    $response = []; //Data Response

    //Cek username didalam databse
    $userQuery = "SELECT * FROM user JOIN register ON user.id_user = register.id_user WHERE email = '$email' ;";
    $result = mysqli_query($konek, $userQuery);
    $row = mysqli_fetch_array($result);

    if ($row == 0) {
        $response['status'] = false;
        $response['message'] = "Email Tidak Terdaftar";
    } else {
        // Ambil password di db
        $passwordDB = $row['password'];
        $verify = password_verify($pass, $passwordDB);
        if ($verify) {
            $response['status'] = true;
            $response['message'] = "Login Berhasil";
            $response['data'] = [
                'id_user' => $row['id_user'],
                'email' => $row['email'],
                'password' => $row['password'],
                'verify_status' => $row['verify_status'],
                'nama' => $row['nama']
            ];
        } else {
            $response['status'] = false;
            $response['message'] = "Password anda salah";
        }
    }

    //Jadikan data JSON
    $json = json_encode($response, JSON_PRETTY_PRINT);

    //Print
    echo ($json);
}