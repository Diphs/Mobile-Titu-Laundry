<?php
require("conn.php");
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $query = "SELECT * FROM banner";
    $queryExecute = mysqli_query($konek, $query);
    $Check = mysqli_affected_rows($konek);

    if ($Check > 0) {
        $response["Kode"] = 1;
        $response["Pesan"] = "Data Tersedia";
        $response["Data"] = array();

        while ($getData = mysqli_fetch_object($queryExecute)) {
            $F["id_banner"] = $getData->id_banner;
            $F["image"] = $getData->image;
            array_push($response["Data"], $F);
        }
    } else {
        $response["Kode"] = 0;
        $response["Pesan"] = "Data Tidak Tersedia";
    }

    echo json_encode($response);
    mysqli_close($konek);
}