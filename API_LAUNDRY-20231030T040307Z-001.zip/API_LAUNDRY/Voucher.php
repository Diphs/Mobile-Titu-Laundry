<?php
require("conn.php");
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $query = "SELECT * FROM voucher WHERE NOT id_voucher = '1' AND NOT slot_voucher = '0' AND status = 'Active';";
    $queryExecute = mysqli_query($konek, $query);
    $Check = mysqli_affected_rows($konek);

    if ($Check > 0) {
        $response["Kode"] = 1;
        $response["Pesan"] = "Data Tersedia";
        $response["Data"] = array();

        while ($getData = mysqli_fetch_object($queryExecute)) {
            $F["id_voucher"] = $getData->id_voucher;
            $F["potongan_harga"] = $getData->potongan_harga;
            $F["slot_voucher"] = $getData->slot_voucher;
            $F["nama"] = $getData->nama;

            array_push($response["Data"], $F);
        }
    } else {
        $response["Kode"] = 0;
        $response["Pesan"] = "Data Tidak Tersedia";
    }

    echo json_encode($response);
    mysqli_close($konek);
}