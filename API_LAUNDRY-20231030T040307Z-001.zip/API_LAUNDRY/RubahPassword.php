<?php
include 'conn.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_user = $_POST['id_user'];
    $password = $_POST['password'];
    $password2 = $_POST['password2'];

    $query = "SELECT password FROM user WHERE id_user = '$id_user';";
    $result = mysqli_query($konek, $query);
    $row = mysqli_fetch_array($result);

    $passwordDB = $row['password'];
    $verify = password_verify($password, $passwordDB);

    if ($verify) {
        $hash = password_hash($password2, PASSWORD_DEFAULT);
        $queryUpdate = "UPDATE user SET password = '$hash' WHERE id_user = '$id_user'";
        $result = mysqli_query($konek, $queryUpdate);
        $check = mysqli_affected_rows($konek);
        if ($check > 0) {
            $response['kode'] = 1;
            $response['message'] = "Berhasil Update Password";
        } else {
            $response['kode'] = 0;
            $response['message'] = "gagal Update Password";
        }
    } else {
        $response['kode'] = 2;
        $response['message'] = "password Lama Tidak Sesuai";
    }


    echo json_encode($response);
    mysqli_close($konek);
}