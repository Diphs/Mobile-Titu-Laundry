<?php
include('conn.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $id_user = $_POST['id_user'];
    $alamat = $_POST['alamat'];


    $queryCheck = "UPDATE user SET alamat = '$alamat' WHERE id_user = '$id_user';";
    $checkEmail = mysqli_query($konek, $queryCheck);
    $rowsEmail = mysqli_affected_rows($konek);

    if ($rowsEmail > 0) {
        $response['kode'] = 1;
        $response['message'] = "Alamat Telah diUpdate";
    } else {
        $response['kode'] = 0;
        $response['message'] = "Gagal Menambahkan alamat";
    }

    echo json_encode($response);
    mysqli_close($konek);
}