<?php
$digits = 5;
$verifNumber =  rand(pow(10, $digits - 1), pow(10, $digits) - 1);
echo ($verifNumber);