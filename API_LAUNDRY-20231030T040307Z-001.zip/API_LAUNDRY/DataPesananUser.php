<?php
require('conn.php');
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $id_pesanan = $_POST['id_pesanan'];

    $querySelect = "SELECT pesanan.tanggal,jasa.jenis_jasa,pesanan.total_berat,pesanan.status_pesanan,
    pesanan.waktu_antar,pesanan.alamat_penjemputan,pesanan.alamat_pengiriman ,user.nama,jasa.harga,
    pesanan.total_harga,jasa.image , pesanan.harga_diskon
    FROM pesanan JOIN jasa ON jasa.id_jasa = pesanan.id_jasa 
    JOIN user ON user.id_user = pesanan.id_user WHERE pesanan.id_pesanan = '$id_pesanan'";
    $result = mysqli_query($konek, $querySelect);
    $row = mysqli_fetch_array($result);

    if ($row > 0) {
        $response['kode'] = 1;
        $response['message'] = "Data Tersedia";
        $response['data'] = [
            'tanggal' => $row['tanggal'],
            'jenis_jasa' => $row['jenis_jasa'],
            'total_berat' => $row['total_berat'],
            'status_pesanan' => $row['status_pesanan'],
            'waktu_antar' => $row['waktu_antar'],
            'alamat_penjemputan' => $row['alamat_penjemputan'],
            'alamat_pengiriman' => $row['alamat_pengiriman'],
            'nama' => $row['nama'],
            'harga' => $row['harga'],
            'total_harga' => $row['total_harga'],
            'image' => $row['image'],
            'harga_diskon' => $row['harga_diskon']
        ];
    } else {
        $response['kode'] = 0;
        $response['message'] = "Data Kosong";
    }

    $json = json_encode($response, JSON_PRETTY_PRINT);

    //Print
    echo ($json);
}