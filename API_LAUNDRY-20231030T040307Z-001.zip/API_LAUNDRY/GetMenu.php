<?php
require("conn.php");
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $query = "SELECT * FROM jasa";
    $queryExecute = mysqli_query($konek, $query);
    $Check = mysqli_affected_rows($konek);

    if ($Check > 0) {
        $response["Kode"] = 1;
        $response["Pesan"] = "Data Tersedia";
        $response["Data"] = array();

        while ($getData = mysqli_fetch_object($queryExecute)) {
            $F["id_jasa"] = $getData->id_jasa;
            $F["jenis_jasa"] = $getData->jenis_jasa;
            $F["deskripsi"] = $getData->deskripsi;
            $F["durasi"] = $getData->durasi;
            $F["harga"] = $getData->harga;
            $F["image"] = $getData->image;

            array_push($response["Data"], $F);
        }
    } else {
        $response["Kode"] = 0;
        $response["Pesan"] = "Data Tidak Tersedia";
    }

    echo json_encode($response);
    mysqli_close($konek);
}